package geography;


public class boundary {
}
