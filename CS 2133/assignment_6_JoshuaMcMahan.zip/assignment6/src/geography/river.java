package geography;


import java.util.ArrayList;

public class river {

    ArrayList<city> cities;
    private String riverNames;

    public river(String rivers){

        riverNames = rivers;
        cities = new ArrayList<>();
    }

    public void addCity(city cities){

        /*
        add the city to the cities arraylist.
         */
    }
}
