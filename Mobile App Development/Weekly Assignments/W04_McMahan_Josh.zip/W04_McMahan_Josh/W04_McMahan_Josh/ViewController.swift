//
//  ViewController.swift
//  W04_McMahan_Josh
//
//  Created by joshua mcmahan on 9/14/18.
//  Copyright © 2018 joshua mcmahan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

