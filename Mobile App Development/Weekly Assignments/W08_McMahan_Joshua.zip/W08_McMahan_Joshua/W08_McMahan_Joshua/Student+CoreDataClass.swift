//
//  Student+CoreDataClass.swift
//  W08_McMahan_Joshua
//
//  Created by joshua mcmahan on 10/17/18.
//  Copyright © 2018 joshua mcmahan. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Student)
public class Student: NSManagedObject {
    var scooterCompanies = ["Lime", "Bird"]
}
