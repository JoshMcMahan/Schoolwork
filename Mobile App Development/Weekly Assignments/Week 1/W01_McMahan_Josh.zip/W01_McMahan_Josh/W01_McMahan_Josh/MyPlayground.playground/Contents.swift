import UIKit
import W01_McMahan_Josh

var Money0 = Cash(Currency: 23.86)
var Money1 = Cash(Currency: 12.15)
var Money2 = Cash(Currency: 38.92)
var Money3 = Cash(Currency: 49.99)
var Money4 = Cash(Currency: -1.50)
var Money5 = Cash(Currency: 47.23)


let change0 = Money0.getMoney()
let change1 = Money1.getMoney()
let change2 = Money2.getMoney()
let change3 = Money3.getMoney()
let change4 = Money4.getMoney()
let change5 = Money5.getMoney()



