//
//  W01_McMahan_Josh.h
//  W01_McMahan_Josh
//
//  Created by joshua mcmahan on 8/24/18.
//  Copyright © 2018 joshua mcmahan. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for W01_McMahan_Josh.
FOUNDATION_EXPORT double W01_McMahan_JoshVersionNumber;

//! Project version string for W01_McMahan_Josh.
FOUNDATION_EXPORT const unsigned char W01_McMahan_JoshVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <W01_McMahan_Josh/PublicHeader.h>


