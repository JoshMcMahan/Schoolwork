// prefer default export if available
const preferDefault = m => m && m.default || m

exports.components = {
  "component---cache-dev-404-page-js": () => import("/Users/woodshiro/Documents/Development/Schoolwork/Web App Development/McMahan/.cache/dev-404-page.js" /* webpackChunkName: "component---cache-dev-404-page-js" */),
  "component---src-pages-index-js": () => import("/Users/woodshiro/Documents/Development/Schoolwork/Web App Development/McMahan/src/pages/index.js" /* webpackChunkName: "component---src-pages-index-js" */)
}

exports.data = () => import("/Users/woodshiro/Documents/Development/Schoolwork/Web App Development/McMahan/.cache/data.json")

