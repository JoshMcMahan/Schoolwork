
public class CosFunc extends Function {
    public double evaluate(double x) {
       return Math.cos(x);
    }
}

/** CosFunc uses evaluate to find the cos(x)
 *
 */