
public class SinFunc extends Function{
        public double evaluate(double x) {
           return Math.sin(x);
        }
    }

/** SinFunc uses evaluate to find the sin(x)
 *
 */