
public class Message {

    public static void main(String[] args) {

        new MessageFrame();
    }
}