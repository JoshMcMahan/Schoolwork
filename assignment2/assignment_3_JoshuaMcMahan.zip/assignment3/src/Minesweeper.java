
public class Minesweeper {
    public static void main(String[] args){

        new MineFrame();
    }
}
