
public class SierpinskiMain {

    public static void main(String[] args) {

        new SierpinskiFrame();
    }
}

