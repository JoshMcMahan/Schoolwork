public class RobotMain {

    public static void main(String[] args) {
        new RobotFrame();
    }
}