
public class WebMain
{
    public static void main(String[] args){
        new WebFrame();

    }
}
